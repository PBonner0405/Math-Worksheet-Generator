import React from 'react';

const Footer = () => {
    return (
        <footer>
            Contact Me: +1 123 456 7890
        </footer>
    )
}

export default Footer;