import React from 'react';

const NotFound = () => {
    return (
        <main>
            NotFound!!!
        </main>
    )
}

export default NotFound;