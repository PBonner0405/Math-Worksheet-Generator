import NotFound from './notfound';

export {
    NotFound
};